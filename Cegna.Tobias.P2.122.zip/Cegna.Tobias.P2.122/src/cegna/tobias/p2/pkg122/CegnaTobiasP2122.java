/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cegna.tobias.p2.pkg122;

import config.RutasArchivos;
import java.io.IOException;
import model.Hechizos;
import model.LibrodeHechizos;
import model.TipoHechizo;

/**
 *
 * @author tobia
 */
public class CegnaTobiasP2122 {

    public static void main(String[] args) {
        try {
            LibrodeHechizos<Hechizos> libro = new LibrodeHechizos<>();
            libro.agregar(new Hechizos(1, "Expelliarmus", "Flitwick", TipoHechizo.DEFENSA));
            libro.agregar(new Hechizos(2, "Alohomora", "Desconocido", TipoHechizo.UTILIDAD));
            libro.agregar(new Hechizos(3, "Sectumsempra", "Severus Snape", TipoHechizo.OSCURO));
            libro.agregar(new Hechizos(4, "Lumos", "Desconocido", TipoHechizo.ENCANTAMIENTO));
            libro.agregar(new Hechizos(5, "Vulnera Sanentur", "Snape", TipoHechizo.CURACION));
// Mostrar todos los hechizos
            System.out.println("Hechizos:");
            libro.paraCadaElemento(h -> System.out.println(h));
// Filtrar por tipo DEFENSA
            System.out.println("\nHechizos de tipo DEFENSA:");
            libro.filtrar(h -> h.getTipohechizo() == TipoHechizo.DEFENSA).forEach(h -> System.out.println(h));

// Filtrar por nombre que contenga "lumos"
            System.out.println("\nHechizos que contienen 'Lumos':");
            libro.filtrar(h -> h.getNombre().contains("Lumos")).forEach(h -> System.out.println(h));

// Ordenar hechizos por ID (orden natural)
            System.out.println("\nHechizos ordenados por ID:");
            libro.ordenar(null);
            libro.paraCadaElemento(h -> System.out.println(h));
// Ordenar hechizos por nombre
            System.out.println("\nHechizos ordenados por nombre:");
            libro.ordenar(((h1, h2) -> h1.getNombre().compareTo(h2.getNombre())));
            

// Guardar en archivo binario
            libro.guardarEnArchivo(RutasArchivos.getPathBinString());

// Cargar desde archivo binario
            LibrodeHechizos<Hechizos> libroCargado = new LibrodeHechizos<>();
            libroCargado.cargarDesdeArchivo(RutasArchivos.getPathBinString());
            System.out.println("\nHechizos cargados desde archivo binario:");
            libroCargado.paraCadaElemento(h -> System.out.println(h));

// Guardar en archivo CSV
            libro.guardarEnCSV(RutasArchivos.getPathCSVString());
             // Cargar desde archivo CSV

            libroCargado.cargarDesdeCSV(RutasArchivos.getPathCSVString());
            System.out.println("\nHechizos cargados desde archivo CSV:");
            libroCargado.paraCadaElemento(h -> System.out.println(h));
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
