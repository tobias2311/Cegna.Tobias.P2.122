/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistence;

/**
 *
 * @author tobia
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import model.Hechizos;

public interface PersistenciaHechizos {

    static void guardarHechizosCSV(List<? extends Hechizos> lista, String path) throws IOException{
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {

            escritor.write(Hechizos.toCSVHeader());

            for (Hechizos e : lista) {
                escritor.write(e.toCSV());
                escritor.newLine();
            }

        } 
    }

    static List<Hechizos> cargarHechizosCSV(String path) throws IOException{
        List<Hechizos> toReturn = new ArrayList<>();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            String datos;
            lector.readLine();
            while ((datos = lector.readLine()) != null) {
                toReturn.add(Hechizos.fromCSV(datos));
            }
        } 
        return toReturn;
    }

    static void serializarHechizos(List<? extends Hechizos> lista, String path) throws IOException{
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {

            salida.writeObject(lista);

        } 
    }

    static List<Hechizos> deserializarHechizos(String path)throws IOException, ClassNotFoundException{
        List<Hechizos> toReturn = new ArrayList<>();

        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<Hechizos>) entrada.readObject();

        } 
        return toReturn;
    }
}
