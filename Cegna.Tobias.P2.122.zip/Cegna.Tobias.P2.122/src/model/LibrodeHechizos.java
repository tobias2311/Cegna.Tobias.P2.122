/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class LibrodeHechizos<T extends CSVSerializable> {

    private List<T> listaHechizos = new ArrayList();

    public void agregar(T item) {
        listaHechizos.add(Objects.requireNonNull(item));
    }

    public void eliminar(int indice) {
        if (validarIndice(indice)) {
            listaHechizos.remove(indice);
        }
    }

    public T obtenerElemento(int indice) {
        if (validarIndice(indice)) {
            return listaHechizos.get(indice);
        } else {
            throw new IndexOutOfBoundsException();
        }
    }

    private boolean validarIndice(int indice) {
        boolean toReturn = true;
        if (indice > listaHechizos.size() || indice < 0) {
            toReturn = false;
        }
        return toReturn;
    }

    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> listaNueva = new ArrayList<>();

        for (T t : listaHechizos) {
            if (criterio.test(t)) {
                listaNueva.add(t);
            }
        }
        return listaNueva;
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T Hechizos : listaHechizos) {
            accion.accept(Hechizos);
        }
    }

    public void ordenar(Comparator<? super T> criterio) {
        listaHechizos.sort(criterio);
    }
    
    public void guardarEnCSV(String path)throws IOException {
        persistence.PersistenciaHechizos.guardarHechizosCSV((List<? extends Hechizos>) listaHechizos, path);
    }

    public List<Hechizos> cargarDesdeCSV(String path)throws IOException {
        listaHechizos = (List<T>) persistence.PersistenciaHechizos.cargarHechizosCSV(path);
        return (List<Hechizos>) listaHechizos;
    }

    public void guardarEnArchivo(String path)throws IOException {
        persistence.PersistenciaHechizos.serializarHechizos((List<? extends Hechizos>) listaHechizos, path);
    }

    public List<Hechizos> cargarDesdeArchivo(String path)throws IOException, ClassNotFoundException {
        listaHechizos = (List<T>) persistence.PersistenciaHechizos.deserializarHechizos(path);
        return (List<Hechizos>) listaHechizos;
    }
}
