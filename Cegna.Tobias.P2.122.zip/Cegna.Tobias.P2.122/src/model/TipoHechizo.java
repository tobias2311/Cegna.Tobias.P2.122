/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author tobia
 */
import java.io.Serializable;

public enum TipoHechizo implements Serializable {
    ATAQUE,
    DEFENSA,
    UTILIDAD,
    OSCURO,
    CURACION,
    ENCANTAMIENTO
}
