/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

/**
 *
 * @author tobia
 */
public class Hechizos implements Comparable<Hechizos>, CSVSerializable, Serializable {
    private int id;
    private String nombre;
    private String creador;
    private TipoHechizo tipohechizo;

    public Hechizos(int id, String nombre, String creador, TipoHechizo tipohechizo) {
        this.id = id;
        this.nombre = nombre;
        this.creador = creador;
        this.tipohechizo = tipohechizo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCreador() {
        return creador;
    }

    public TipoHechizo getTipohechizo() {
        return tipohechizo;
    }

    @Override
    public String toString() {
        return "Hechizos " + " id " + id + " nombre " + nombre + " creador " + creador + " tipohechizo " + tipohechizo;
    }
    
    
    public int compareTo(Hechizos h) {
        return Integer.compare(this.id, h.getId() );
    }

    
    public String toCSV() {
        return id + "," + nombre + "," + creador + "," + tipohechizo;
    }

    public static Hechizos fromCSV(String linea) {
        Hechizos toReturn = null;
        String[] partes = linea.split(",");

        if (partes.length == 4) {
            int idNuevo = Integer.parseInt(partes[0]);
            String nombreNuevo = partes[1];
            String creadorNuevo = partes[2];
            TipoHechizo tipohechizoNuevo = TipoHechizo.valueOf(partes[3]);
            toReturn = new Hechizos(idNuevo, nombreNuevo, creadorNuevo, tipohechizoNuevo);
        }

        return toReturn;

    }

    public static String toCSVHeader() {
        return "id,titulo,director,genero\n";
    }
    
    
    
}
